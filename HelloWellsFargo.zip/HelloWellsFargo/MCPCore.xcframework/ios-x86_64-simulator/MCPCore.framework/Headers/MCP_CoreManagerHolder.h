//
//  MCP_CoreManagerHolder.h
//  MCPCore
//
//  Created by Richard Perry on 3/29/22.
//

#ifndef MCP_CoreManagerHolder_h
#define MCP_CoreManagerHolder_h

#include <stdio.h>
#include <memory>

#include "MapNextCoreManager.h"
#include "MCP.h"

MCP_BEGIN_EXPORT()

class MapNextInterception;
struct ConfigProfile;

class MCP_CoreManagerHolder {
    
public:
    MCP_CoreManagerHolder();
    static MCP_CoreManagerHolder* mainHolder();
    MapNextInterception* getMapNextInterception();
    std::shared_ptr<ConfigProfile> getCurrentProfile();
    void setCoreManager(MapNextCoreManager* manager);
    MapNextCoreManager *getCoreManager();
private:
    MapNextCoreManager *coreManager;
};

MCP_END_EXPORT()

#endif /* MCP_CoreManagerHolder_h */

//
//  MAP_HTTPCacheFixup.h
//  mapnext_injectable_ios
//
//  Created by Brian Pescatore on 11/5/15.
//
//

#import <Foundation/Foundation.h>

@interface MAP_HTTPCacheFixup : NSURLProtocol

+ (void) registerProtocol;

@end

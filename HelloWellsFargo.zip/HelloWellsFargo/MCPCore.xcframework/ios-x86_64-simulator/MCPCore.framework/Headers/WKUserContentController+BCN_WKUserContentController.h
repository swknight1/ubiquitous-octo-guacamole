//
//  WKUserContentController+BCN_WKUserContentController.h
//  MAPNextLink
//
//  Created by Connor Kelley on 1/31/18.
//  Copyright © 2018 Blue Cedar Networks. All rights reserved.
//  Licensed to Microsoft under Contract #7267038.
//

#import <WebKit/WebKit.h>

@interface WKUserContentController (BCN_WKUserContentController)

+(BOOL)performSwizzle;

-(void)addBCNScript:(WKUserScript *)script;

@end

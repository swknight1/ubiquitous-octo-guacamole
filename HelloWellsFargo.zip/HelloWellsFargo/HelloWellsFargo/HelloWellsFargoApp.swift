//
//  HelloWellsFargoApp.swift
//  HelloWellsFargo
//
//  Created by Shawn W Knight on 10/19/22.
//

import SwiftUI

@main
struct HelloWellsFargoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

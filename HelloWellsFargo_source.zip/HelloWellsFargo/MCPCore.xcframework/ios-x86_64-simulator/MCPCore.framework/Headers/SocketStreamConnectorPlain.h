//
//  SocketStreamConnectorPlain.h
//  MAPNextLink
//
//  Created by Richard Perry on 3/13/19.
//  Copyright © 2019 Blue Cedar Networks. All rights reserved.
//  Licensed to Microsoft under Contract #7267038.
//

#import <Foundation/Foundation.h>
#import "SocketStreamConnectorBase.h"

@interface SocketStreamConnectorPlain : SocketStreamConnectorBase

@end


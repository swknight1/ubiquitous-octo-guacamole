//
//  MAP_NSHTTPCookieStorage.h
//  mapnext_injectable_ios
//
//  Created by Tim Champagne Jr. on 9/24/15.
//
//

#import <Foundation/Foundation.h>

@interface MAP_NSHTTPCookieStorage : NSHTTPCookieStorage

@end

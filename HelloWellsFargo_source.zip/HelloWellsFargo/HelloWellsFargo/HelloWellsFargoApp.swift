//
//  HelloWellsFargoApp.swift
//  HelloWellsFargo
//
//  Created by user229388 on 10/19/22.
//

import SwiftUI

@main
struct HelloWellsFargoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

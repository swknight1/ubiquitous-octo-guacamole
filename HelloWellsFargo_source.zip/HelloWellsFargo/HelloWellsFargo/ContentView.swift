//
//  ContentView.swift
//  HelloWellsFargo
//
//  Created by user229388 on 10/19/22.
//

import SwiftUI

struct ContentView: View {
    @State private var api:String=""
    @State private var result: String = ""
    
    
    var body: some View {
        VStack {
            
            Text("Hello, Wells Fargo!").bold().font(.largeTitle).padding(20)
            Text("Enter the API URL:")
            
            TextField(text:$api){Text("URL goes here")}.frame(maxWidth:150, alignment: .center)
            Button {
                Task {
                    let (data, _) = try await URLSession.shared.data(from: URL(string:api)!)
                    let decodedResponse = try? JSONDecoder().decode(Result.self, from: data)
                    result = decodedResponse?.value ?? "No response"
                }
            } label: {
                Text("Consume API")
            }
            .padding()
        }
        Text("Result:")
        Text(result)
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Result: Codable {
    let value: String
}
